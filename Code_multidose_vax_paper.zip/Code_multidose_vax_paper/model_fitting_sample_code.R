####Example script for model-fitting using the CP method - DTP1

#Load libraries
library(INLA)
INLA:::inla.dynload.workaround()
library(raster); library(maptools)
library(gtools); library(sp); library(spdep)
library(rgdal)
library(ggplot2)

#Create file paths
filePathData <- "/..../"
filePathData1 <- "/..../"
filePathData2 <- "/..../"

set.seed(500)

#loading the data
vaxdata <- read.csv(paste0(filePathData,"....csv"), header=TRUE) #Vaccination coverage data
vaxcov  <- read.csv(paste0(filePathData,"....csv"),header=TRUE) #Covariate data

#Align both data sets using DHS cluster IDs
data.merge <- merge(vaxdata, vaxcov, by="DHSCLUST")

vaxcov  <- data.merge[,19:26]   #Covariate data including lon-lat coordinates 
vaxdata <- data.merge[,3:17]    #Vaccination coverage data


#Delete clusters where the total no of childlren sampled is zero or 1
zero.clust <- which(is.na(vaxdata$total)|vaxdata$total<=1)
if (length(zero.clust)>0){
  vaxdata <- vaxdata[-zero.clust,]
  vaxcov  <- vaxcov[-zero.clust,]
}

#Example using DTP1
Numvacc    <- vaxdata$dtp1_count
weights    <- vaxdata$total

#Coordinates
coords    <- cbind(vaxdata$LONGNUM,vaxdata$LATNUM)

#Covariates
xp1     <- vaxcov$educ.prop
xp2     <- vaxcov$religion.prop
xp3	<- vaxcov$sba.prop
xp4	<- vaxcov$l_n66_pigs_density_mean
xp5	<- vaxcov$URBAN_RURAL1
xp6     <- vaxcov$l_n28_viirs_nightlights_mean
xp7     <- vaxcov$wealth.prop 
xp8     <- vaxcov$n95_proximity_national_borders_mean
 

#Read in prediction covariate raster files
educ.prop  	<- raster(paste0(filePathData,"educkrig.tif"))
religion.prop  	<- raster(paste0(filePathData,"religionkrig.tif")) 
sba.prop 	<- raster(paste0(filePathData,"sbakrig.tif"))
l_n66_Mean  	<- raster(paste0(filePathData,"n66_pigs_1km_final.tif"))
urban_rural	<- raster(paste0(filePathData,"NGA_urban_rural_1km_NEW.tif"))
l_n28_Mean	<- raster(paste0(filePathData,"n28_viirs_nightlights.tif"))
wealth.prop	<- raster(paste0(filePathData,"wealthkrig.tif"))
n95_Mean	<- raster(paste0(filePathData,"n95_proximity_national_borders.tif"))


#Extract values of covariates from the raster files
x1gp  	<- getValues(educ.prop)
x2gp 	<- getValues(religion.prop)
x3gp 	<- getValues(sba.prop)   			
x4gp	<- log(getValues(l_n66_Mean) + 0.05)
x5gp	<- getValues(urban_rural) 
x6gp	<- log(getValues(l_n28_Mean) + 0.05)
x7gp	<- getValues(wealth.prop) 
x8gp	<- getValues(n95_Mean) 

#Prediction grid
n25.p      <- raster(paste0(filePathData,"n95_proximity_national_borders.tif"))
Pred_grid2 <- coordinates(n25.p)

#Population data for population-weighted aggregation
popc     <- raster(paste0(filePathData,"..._WorldPop_under5s_2018.tif"))
popc	 <- getValues(popc) 

#Combine prediction grid and covariates, process to remove all grid cells with missing values
pred.dat <- cbind(Pred_grid2, x1gp, x2gp, x3gp, x4gp, x5gp, x6gp, x7gp, x8gp, popc) # 

ind     <- apply(pred.dat, 1, function(x) any(is.na(x)))
miss    <- which(ind==TRUE)
nonmiss <- which(ind==FALSE)

pred.dat.1 <- pred.dat[nonmiss, ]
pop        <- pred.dat.1[,11]             
coord.p    <- pred.dat.1[,1:2]
ypred=npred=rep(NA, nrow(pred.dat.1))

#Admin0 shapefile for Nigeria
shp_ng  <- readShapePoly(paste0(filePathData1,"gadm36_NGA_0.shp"))

#meshfit: fine triangulated mesh
shp_df <- fortify(shp_ng)
shp.bnd <- cbind(shp_df$long, shp_df$lat)
c.bnd <- as.matrix(shp.bnd)	
meshfit <- inla.mesh.2d(loc=coords,loc.domain=c.bnd, max.edge=c(0.05, 0.6),cutoff=0.1)			
#plot(meshfit); plot(shp_ng, add=TRUE); points(coords)

#For priors
r0    <- 0.48 #This is 5% of the extent of Nigeria in the north-south direction (i.e. 0.05*(ymax-ymin))
n     <- 1 #Matern smoothness parameter, redundant here as it implies alpha=2
alpha <- 2

#Matern SPDE model object using inla.pcmatern
spde <- inla.spde2.pcmatern(mesh=meshfit, alpha=alpha, prior.range=c(r0, 0.01), prior.sigma=c(3, 0.01)) 

#For LGA-level estimates
coord.p <- pred.dat.1[,1:2]
spol1   <- readShapePoly(paste0(filePathData1,"Detailed_Boundary_ADM2.shp"))
spol    <- as(spol1, "SpatialPolygons")   #NOTE - no data in spol
sp.1    <- rep(NA, nrow(coord.p))
for(i in 1:length(spol)){
  sp.1[as.vector(which(!is.na(over(SpatialPoints(coord.p), spol[i]))))] <- i
}

#For State-level estimates
spol2   <- readShapePoly(paste0(filePathData1,"Detailed_Boundary_ADM1.shp"))
spol    <- as(spol2, "SpatialPolygons")   #NOTE - no data in spol
sp.2    <- rep(NA, nrow(coord.p))
for(i in 1:length(spol)){
  sp.2[as.vector(which(!is.na(over(SpatialPoints(coord.p), spol[i]))))] <- i
}

#For Regional-level estimates
spol3   <- readShapePoly(paste0(filePathData1,"sdr_subnational_boundaries.shp"))
spol    <- as(spol3, "SpatialPolygons")   #NOTE - no data in spol
sp.3    <- rep(NA, nrow(coord.p))
for(i in 1:length(spol)){
  sp.3[as.vector(which(!is.na(over(SpatialPoints(coord.p), spol[i]))))] <- i
}

# Observation points
X0 <- model.matrix(~ -1 + xp1 + xp2 + xp3 + xp4 + factor(xp5) + xp6 + xp7 + xp8)
Xobs <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(xp5)0"))])
colnames(Xobs) <- c("x1", "x2", "x3", "x4", "x5_1", "x6", "x7", "x8")  
Ap.i <- inla.spde.make.A(mesh=meshfit, loc=coords)
lp.i = rep(1,length(xp1))
stk.point <- inla.stack(tag='point',
                        data=list(y=Numvacc,n=weights),
                        A=list(Ap.i,1,1,1),
                        effects=list(s=1:spde$n.spde, rr=1:length(weights), intercept=rep(1, length(xp1)), Xobs))  

# Prediction points - not used during model-fitting
xpred1 <- pred.dat.1[,3]; xpred2 <- pred.dat.1[,4]; xpred3 <- pred.dat.1[,5] 
xpred4 <- pred.dat.1[,6]; xpred5 <- pred.dat.1[,7]; xpred6 <- pred.dat.1[,8]
xpred7 <- pred.dat.1[,9]; xpred8 <- pred.dat.1[,10]

X0 <- model.matrix(~ -1 + xpred1 + xpred2 + xpred3 + xpred4 + factor(xpred5) + xpred6 + xpred7 + xpred8)
 
Xpred <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(xpred5)0"))])
colnames(Xpred) <- c("x1", "x2", "x3", "x4", "x5_1", "x6", "x7", "x8") 
Apred <- inla.spde.make.A(mesh=meshfit, loc=coord.p)
lpred = rep(1,nrow(pred.dat.1))
stk.pred <- inla.stack(tag='pred',
                       data=list(y=ypred,n=npred),
                       A=list(Apred,1,1),
                       effects=list(s=1:spde$n.spde, rr=(length(weights)+1):(length(weights)+nrow(pred.dat.1)), Xpred)) 

# Stack object
stk.full <- inla.stack(stk.point)  #Note no stk.pred as prediction is done post model-fitting

# Fit model
#Additional priors
hyper.prec = list(theta = list(prior="pc.prec", param=c(3,0.01)))
control.fixed = list(mean=0, prec=1/1000, mean.intercept=0, prec.intercept=1/1000)  

#Formula                                                    
formula  <- y ~ -1 + intercept + x1 + x2 + x3 + x4 + x5_1 + x6 + x7 + x8 + f(s, model=spde) + f(rr, model="iid", hyper = hyper.prec) 
res <- inla(formula, data=inla.stack.data(stk.full), family="binomial", 
            Ntrials = stk.full$data$data$n,
            control.predictor=list(compute=TRUE, A=inla.stack.A(stk.full), link=1),
            control.compute=list(dic=TRUE, config = TRUE, waic=TRUE),
            control.fixed=control.fixed)

#save model
save(res, file=paste0(filePathData2,"inla_model_dtp1_12_23m.rda"))

spde.result <- inla.spde2.result(inla=res,name="s",spde=spde)

#Parameters
coeff.reg <- summary(res)$fixed[,1:5]

#range for spatial RE
range.mean = inla.emarginal(function(x) x, spde.result$marginals.range.nominal[[1]]); #range.mean
range.ex.sq = inla.emarginal(function(x) x^2, spde.result$marginals.range.nominal[[1]])
range.sd = sqrt(range.ex.sq-(range.mean^2)); #range.sd
range.quant = inla.qmarginal(c(0.025,0.5,0.975), spde.result$marginals.range.nominal[[1]]);# range.quant 
range <- c(range.mean, range.sd, range.quant)

#variance for spatial RE
variance.mean = inla.emarginal(function(x) x, spde.result$marginals.variance.nominal[[1]]); #variance.mean
variance.ex.sq = inla.emarginal(function(x) x^2, spde.result$marginals.variance.nominal[[1]])
variance.sd = sqrt(variance.ex.sq-(variance.mean^2)); #variance.sd
variance.quant = inla.qmarginal(c(0.025,0.5,0.975), spde.result$marginals.variance.nominal[[1]]); #variance.quant 
variance <- c(variance.mean, variance.sd, variance.quant)

#variance for IID RE
#variance of IID random effect
  
var.ind      <- inla.tmarginal(function(x) 1/x, res$marginals.hyperpar[[3]])
  
var.iid      <- inla.zmarginal(var.ind,silent=TRUE)
  
variance.iid <- c(var.iid$mean, var.iid$sd, var.iid$quant0.025, var.iid$quant0.5, var.iid$quant0.975)

#iid.var <- res$summary.hyperpar[3,1:5]
param.all <- rbind(coeff.reg,range,variance, variance.iid)

write.csv(param.all, paste0(filePathData2, "parameter_output_dtp1_12_23.csv"))


#Observation points
index.pred.obs 	<- inla.stack.index(stk.full, tag = "point")$data
fitted.pred.all.obs = round(res$summary.fitted.values[index.pred.obs,1:5], 4)
fitted.pred.mean.obs1 = as.vector(data.matrix(as.vector(fitted.pred.all.obs["mean"])))
fitted.pred.sd.obs1 = as.vector(data.matrix(as.vector(fitted.pred.all.obs["sd"])))
fitted.pred.low.obs1 = as.vector(data.matrix(as.vector(fitted.pred.all.obs["0.025quant"])))
fitted.pred.up.obs1 = as.vector(data.matrix(as.vector(fitted.pred.all.obs["0.975quant"])))

prob.obs <- Numvacc/weights
ds <- data.frame(pred.prob=fitted.pred.mean.obs1, pred.obs=prob.obs, Vax=Numvacc, Tot=weights, 
				pred.sd = fitted.pred.sd.obs1, pred.low=fitted.pred.low.obs1, pred.up=fitted.pred.up.obs1)
write.csv(ds, paste0(filePathData2, "obsvpred_dtp1_12_23.csv"))


##################POSTERIOR SAMPLING
nsamp <- 1000

#Posterior sampling
ps <- inla.posterior.sample(nsamp, res) 
contents <- res$misc$configs$contents

#ID for spatial random effect
idSpace <- contents$start[which(contents$tag=="s")]-1 +
  (1:contents$length[which(contents$tag=="s")])

#ID for iid effects
idR <- contents$start[which(contents$tag=="rr")]-1 +
  (1:contents$length[which(contents$tag=="rr")])

#ID for fixed effects
idX <- contents$start[which(contents$tag=="intercept")]-1 + (1:9) # fixed effects, 9 = no of regression coefficients

# extract samples 
xLatent <- matrix(0, nrow=length(ps[[1]]$latent), ncol=nsamp) 
xHyper <- matrix(0, nrow=length(ps[[1]]$hyperpar), ncol=nsamp) 
for(i in 1:nsamp){
  xLatent[,i] <- ps[[i]]$latent
  xHyper[,i] <- ps[[i]]$hyperpar
}
xSpace <- xLatent[idSpace,]
XR <- xLatent[idR,]
xX <- xLatent[idX,]


#Prediction
#Draw samples for IID term
sample.IIDpred <- matrix(0, nrow(pred.dat.1),  nsamp)
for (i in 1:nsamp){
  ID.precision <- xHyper[3,i]                         
  ID.sigma <- ID.precision^-0.5
  sample.IIDpred[, i] <- rnorm(nrow(pred.dat.1), sd=ID.sigma)
}

linpred     <- as.matrix(Apred %*% xSpace + as.matrix(cbind(1, Xpred$x1, Xpred$x2, Xpred$x3, Xpred$x4,  Xpred$x5_1, Xpred$x6, Xpred$x7, Xpred$x8)) %*% xX + sample.IIDpred)  #
inv.linpred <- inv.logit(linpred) 

#Save draws for calculating remaining two indicators
save(inv.linpred, file=paste0(filePathData2,"simprob_dtp1.rda"))

pred.grid    <- data.frame(t(apply(inv.linpred, 1, FUN=function(x){ c(mean(x), sd(x), quantile(x, probs=c(0.025,0.5,0.975)))}))) 
colnames(pred.grid) <- c("mean", "sd", "0.025quant", "0.5quant", "0.975quant")
fitted.pred.mean   <- as.vector(data.matrix(as.vector(pred.grid["mean"])))
fitted.pred.sd     <- as.vector(data.matrix(as.vector(pred.grid["sd"])))
fitted.pred.median <- as.vector(data.matrix(as.vector(pred.grid["0.5quant"])))
fitted.pred.low    <- as.vector(data.matrix(as.vector(pred.grid["0.025quant"])))
fitted.pred.up     <- as.vector(data.matrix(as.vector(pred.grid["0.975quant"])))

n25.p = raster(paste0(filePathData,"n95_proximity_national_borders.tif"))

#Mean
ll=1:length(ind); ll[nonmiss] = fitted.pred.mean; ll[miss] = NA
rr.mean = raster(n25.p); values(rr.mean) = ll

#sd
ll=1:length(ind); ll[nonmiss] = fitted.pred.sd; ll[miss] = NA
rr.sd = raster(n25.p); values(rr.sd) = ll

#low
ll=1:length(ind); ll[nonmiss] = fitted.pred.low; ll[miss] = NA
rr.low = raster(n25.p); values(rr.low) = ll

#up
ll=1:length(ind); ll[nonmiss] = fitted.pred.up; ll[miss] = NA
rr.up = raster(n25.p); values(rr.up) = ll

#median
ll=1:length(ind); ll[nonmiss] = fitted.pred.median; ll[miss] = NA
rr.med = raster(n25.p); values(rr.med) = ll

writeRaster(rr.mean, paste0(filePathData2, "inla_vax_dtp1_12_23_mean.tif"), overwrite=TRUE)
writeRaster(rr.sd,   paste0(filePathData2, "inla_vax_dtp1_12_23_sd.tif"), overwrite=TRUE)
writeRaster(rr.low,  paste0(filePathData2, "inla_vax_dtp1_12_23_low.tif"), overwrite=TRUE)
writeRaster(rr.up,   paste0(filePathData2, "inla_vax_dtp1_12_23_up.tif"), overwrite=TRUE)
writeRaster(rr.med,  paste0(filePathData2, "inla_vax_dtp1_12_23_median.tif"), overwrite=TRUE)

#Calculate weighted population LGA, State and Regional estimates

#LGA estimates and uncertainty (sd) 
dd    <- 1:nrow(spol1)
dd.un <- unique(sp.1)
dmiss <- which(!dd%in%dd.un)

if (length(dmiss)>0) dd_num <- dd[-dmiss]
if (length(dmiss)==0) dd_num <- dd

dist_out <- matrix(0, length(dd_num), 5)
for (i in 1:length(dd_num)){
  if (length(which(sp.1==dd_num[i]))==1){ 
    pop.ext <- pop[which(sp.1==dd_num[i])] 
    ext <- as.vector(sapply(inv.linpred[which(sp.1==dd_num[i]),], FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE))) 
  }
  if (length(which(sp.1==dd_num[i]))>1){  
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(apply(inv.linpred[which(sp.1==dd_num[i]),], 2, FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  
  dist_out[i,] <- as.vector(c(mean(ext), sd(ext), quantile(ext, probs=c(0.025,0.5,0.975))))						
}

dist_out <- cbind(dd_num, dist_out)
colnames(dist_out) <- c("ID", "mean", "sd", "0.025quant", "0.5quant", "0.975quant")

#The district-level estimates will have the same ordering as in the shapefile if they have the same no of areas
write.csv(dist_out, paste0(filePathData2, "District_estimates_dtp1_12_23.csv"))


#State estimates and uncertainty
dd    <- 1:nrow(spol2)
dd.un <- unique(sp.2)
dmiss <- which(!dd%in%dd.un)

if (length(dmiss)>0) dd_num <- dd[-dmiss]
if (length(dmiss)==0) dd_num <- dd

dist_out <- matrix(0, length(dd_num), 5)
for (i in 1:length(dd_num)){
  if (length(which(sp.2==dd_num[i]))==1){ 
    pop.ext <- pop[which(sp.2==dd_num[i])] 
    ext <- as.vector(sapply(inv.linpred[which(sp.2==dd_num[i]),], FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE))) 
  }
  if (length(which(sp.2==dd_num[i]))>1){  
    pop.ext <- pop[which(sp.2==dd_num[i])]
    ext <- as.vector(apply(inv.linpred[which(sp.2==dd_num[i]),], 2, FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  
  dist_out[i,] <- as.vector(c(mean(ext), sd(ext), quantile(ext, probs=c(0.025,0.5,0.975))))						
}

dist_out <- cbind(dd_num, dist_out)
colnames(dist_out) <- c("ID", "mean", "sd", "0.025quant", "0.5quant", "0.975quant")

#The district-level estimates will have the same ordering as in the shapefile if they have the same no of areas
write.csv(dist_out, paste0(filePathData2, "State_estimates_dtp1_12_23.csv"))


#Regional estimates and uncertainty
dd    <- 1:nrow(spol3)
dd.un <- unique(sp.3)
dmiss <- which(!dd%in%dd.un)

if (length(dmiss)>0) dd_num <- dd[-dmiss]
if (length(dmiss)==0) dd_num <- dd

dist_out <- matrix(0, length(dd_num), 5)
for (i in 1:length(dd_num)){
  if (length(which(sp.3==dd_num[i]))==1){ 
    pop.ext <- pop[which(sp.3==dd_num[i])] 
    ext <- as.vector(sapply(inv.linpred[which(sp.3==dd_num[i]),], FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE))) 
  }
  if (length(which(sp.3==dd_num[i]))>1){  
    pop.ext <- pop[which(sp.3==dd_num[i])]
    ext <- as.vector(apply(inv.linpred[which(sp.3==dd_num[i]),], 2, FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  
  dist_out[i,] <- as.vector(c(mean(ext), sd(ext), quantile(ext, probs=c(0.025,0.5,0.975))))						
}

dist_out <- cbind(dd_num, dist_out)
colnames(dist_out) <- c("ID", "mean", "sd", "0.025quant", "0.5quant", "0.975quant")

#The district-level estimates will have the same ordering as in the shapefile if they have the same no of areas
write.csv(dist_out, paste0(filePathData2, "Region_estimates_dtp1_12_23.csv"))


#Calculate probability of exceeding specified thresholds 
ff1=function(x) length(which(x>=0.80))/nsamp   #Probability of exceeding 80% threshold
y.80 <- apply(inv.linpred, 1, ff1)           
ll=1:length(ind); ll[nonmiss] = y.80; ll[miss] = NA
rr.80 = raster(n25.p); values(rr.80) = ll
writeRaster(rr.80, paste0(filePathData2, "inla_vax_dtp1_12_23_80perc_thresh.tif"), overwrite=TRUE)







